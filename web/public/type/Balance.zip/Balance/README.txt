Balance 1.0

A pixel font in four inks: cyan, magenta, yellow and black. Every letter has 32
printings, and the word around it picks one, so a word prints the same wherever
it appears.

Files
  Balance.otf    Mac and Windows apps
  Balance.ttf    Mac and Windows apps
  Balance.woff2  websites
  Balance.woff   websites, older browsers

Install the OTF or TTF, not both.

Accented letters print as their plain letter: É as E, Ñ as N, Ø as O.

On a website
  @font-face { font-family: "Balance"; src: url(Balance.woff2) format("woff2"); }
  h1 { font-family: "Balance"; }

Black paper: the font carries two palettes. The default prints black ink on white
paper. For white ink on black paper, choose the second palette:

  @font-palette-values --night { font-family: "Balance"; base-palette: 1; }
  h1 { font-family: "Balance"; font-palette: --night; }

Works in browsers, Pages, Keynote and TextEdit. Apps without color font support
show it in one color.

Free under the SIL Open Font License 1.1 (OFL.txt).
