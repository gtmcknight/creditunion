Receipt 1.0

A pixel font in four inks: cyan, magenta, yellow and black. Every letter has 32
printings, and the word around it picks one, so a word prints the same wherever
it appears.

Files
  Receipt.otf    Mac and Windows apps
  Receipt.ttf    Mac and Windows apps
  Receipt.woff2  websites
  Receipt.woff   websites, older browsers

Install the OTF or TTF, not both.

Type in any case and it prints capitals, with the accents of Western and Central
European languages: É, Ñ, Ø, Ł, Ő, Ș and the rest. Other accented letters print as
their plain letter.

On a website
  @font-face { font-family: "Receipt"; src: url(Receipt.woff2) format("woff2"); }
  h1 { font-family: "Receipt"; }

Dark backgrounds: the black ink is your text color. Make the text white and it
prints white.

Sharpest at sizes that are multiples of 10: 10, 20, 30 and so on.

Works in browsers, Pages, Keynote and TextEdit. Apps without color font support
show it in one color.

Free under the SIL Open Font License 1.1 (OFL.txt).
